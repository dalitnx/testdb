# -*- coding: utf-8 -*-
{
    'name': 'Web Gantt View for Project Task(Odoo Enterprise)',
    "author": "Edge Technologies",
    'version': '12.0.1.0',
    'live_test_url': "https://youtu.be/IAmN3_-VNVI",
    "images":['static/description/main_screenshot.png'],
    'summary': "This Apps helps User to View Web Gantt View for Project Task in Half Day, Quarter Day, Half Year and Quarter Year.",
    "description": """
                    Web Gantt View for Project, Gantt View for Project Project Gantt View Ganttview PMS Gantt View Task Gantt View Odoo Gant View Project Ganttview Odoo Project Ganttview Odoo Project Ganttview Odoo Project Web Gantt View View in Gantt Chart Gantt Chart PMS Project Task Gantt View Projact Task Ganttview Project Web Ganttview Task Project Task Web Ganttview Chart Task Gantt View Chart Odoo Web Gantt Chart
                """,
    "license" : "OPL-1",
    'depends': ['base','web_gantt','project'],
    'data': [
            'views/web_gantt_project_task_app_view.xml',
            'views/web_gantt_templates.xml',
            ],
    'qweb': [
        'static/src/xml/*.xml',
    ],
    'installable': True,
    'auto_install': False,
    'price': 000,
    'currency': "EUR",
    'category': 'Projects',

}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
