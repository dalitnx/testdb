Odoo Multi Vendor Marketplace For Odoo 15 By Webkul Software Pvt Ltd
--------------------------------------------------------------------

The Odoo Multi Vendor Marketplace <a href="https://apps.odoo.com/apps/modules/15.0/odoo_marketplace/"></a> app enables online multi vendor marketplace for Sellers to sale their product in easy and better better way with good control over seller profile, seller's commission management, product collection and management etc.

Features:

-------------------------------------------------------------------------------
1. Multi seller/vendor support
-------------------------------------------------------------------------------

Multiple seller can sign up on your e-commerce website as a seller and sale
their own products and you will get commission on that sale.Marketplace owner
can manage all seller's.



-------------------------------------------------------------------------------
2. Seller's commission management
-------------------------------------------------------------------------------

Marketplace owner/manager can manage commission for the seller. Set global
commission for all seller and manage specific commission to the specific seller.


-------------------------------------------------------------------------------
3. Various invoice generation options
-------------------------------------------------------------------------------

Manage various invoices for the customer and the sellers.


-------------------------------------------------------------------------------
4. Separate seller's product collection and management
-------------------------------------------------------------------------------

Every seller can create own products and manage own product only.
Marketplace owner/manage can manage all seller's products.


-------------------------------------------------------------------------------
5. Marketplace product stock management
-------------------------------------------------------------------------------

Seller can request for updating stock value for their products only, then
marketplace owner/manager can take appropriate action on it.


-------------------------------------------------------------------------------
6. Vendor / Seller and Admin moderation and approval
-------------------------------------------------------------------------------

Marketplace owner/manager can manage seller profile, can approve or reject
seller profile.


-------------------------------------------------------------------------------
7. Option to view the list of all the sellers of the marketplace at one place
-------------------------------------------------------------------------------

Marketplace can see all seller records at on place and tack appropriate action.


-------------------------------------------------------------------------------
8. Seller information on product page (on website)
-------------------------------------------------------------------------------

Every marketplace product has information related to seller or seller's shop.


-------------------------------------------------------------------------------
9. Seller profile link and seller shop link on product page
-------------------------------------------------------------------------------

Seller profile link and seller shop link on every marketplace product page.

-------------------------------------------------------------------------------
10. Seller reviews on seller profile page
-------------------------------------------------------------------------------

Customer can see reviews for seller on corresponding seller's profile page.
