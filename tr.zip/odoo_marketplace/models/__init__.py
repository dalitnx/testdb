# -*- coding: utf-8 -*-
#################################################################################
# Author      : Webkul Software Pvt. Ltd. (<https://webkul.com/>)
# Copyright(c): 2015-Present Webkul Software Pvt. Ltd.
# License URL : https://store.webkul.com/license.html/
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://store.webkul.com/license.html/>
#################################################################################

from . import sale
from . import res_users
from . import res_partner
from . import res_config
from . import marketplace_product
from . import seller_payment
from . import account_move
from . import seller_payment_method
from . import stock
from . import ir_action
from . import ir_ui_menu
from . import website
from . import seller_shop
from . import marketplace_dashboard
from . import seller_review
from . import mail
from . import ir_http
from . import ir_attachment
